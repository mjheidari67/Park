package com.mohab.inventoryvoice;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.*;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    EditText plate, note; Spinner country, vehicle, load; TextView status, heard; Button voice, save;
    SpeechRecognizer recognizer; boolean listening=false; ArrayList<JSONObject> rows=new ArrayList<>();
    final String PREF="daily_inventory";

    String[] countries={"انتخاب خودکار","ایران","ترکمنستان","تاجیکستان","قرقیزستان","ازبکستان","ترکیه","قزاقستان","سایرکشورها"};
    String[] vehicles={"کامیون","کشنده","نیمه یدک"}; String[] loads={"پر","خالی"};

    @Override public void onCreate(Bundle b){super.onCreate(b); buildUi(); loadToday();}

    TextView tv(String s){ TextView t=new TextView(this); t.setText(s); t.setTextSize(16); t.setTextColor(0xffeeeeee); t.setPadding(4,12,4,6); return t; }
    LinearLayout root(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(20,16,20,16); l.setBackgroundColor(0xff151515); return l; }
    public void buildUi(){
        LinearLayout r=root(); TextView title=tv("ثبت موجودی روزانه"); title.setTextSize(25); title.setGravity(Gravity.CENTER); r.addView(title);
        status=tv("آماده ثبت"); status.setGravity(Gravity.CENTER); r.addView(status);
        voice=new Button(this); voice.setText("🎙️  ثبت با صدا"); voice.setTextSize(18); r.addView(voice); voice.setOnClickListener(v->startVoice());
        heard=tv(""); heard.setTextSize(15); r.addView(heard);
        r.addView(tv("شماره پلاک")); plate=new EditText(this); plate.setTextSize(23); plate.setSingleLine(); plate.setHint("پلاک را وارد کنید"); plate.setTextColor(0xffffffff); plate.setHintTextColor(0xff888888); r.addView(plate);
        r.addView(tv("کشور")); country=new Spinner(this); country.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,countries)); r.addView(country);
        r.addView(tv("نوع وسیله")); vehicle=new Spinner(this); vehicle.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,vehicles)); r.addView(vehicle);
        r.addView(tv("وضعیت بار")); load=new Spinner(this); load.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,loads)); r.addView(load);
        r.addView(tv("توضیحات (اختیاری)")); note=new EditText(this); note.setSingleLine(); note.setTextColor(0xffffffff); r.addView(note);
        save=new Button(this); save.setText("ثبت نهایی"); save.setTextSize(18); r.addView(save); save.setOnClickListener(v->saveRow());
        setContentView(r); plate.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){} public void onTextChanged(CharSequence s,int a,int b,int c){detectCountry(normalize(s.toString()));} public void afterTextChanged(android.text.Editable e){}});
    }

    String normalize(String s){
        return s.replace('۰','0').replace('۱','1').replace('۲','2').replace('۳','3').replace('۴','4').replace('۵','5').replace('۶','6').replace('۷','7').replace('۸','8').replace('۹','9')
        .replace('٠','0').replace('١','1').replace('٢','2').replace('٣','3').replace('٤','4').replace('٥','5').replace('٦','6').replace('٧','7').replace('٨','8').replace('٩','9')
        .replace(" ","").toUpperCase(Locale.US);
    }
    void detectCountry(String v){
        int idx=0; boolean semi=false, empty=false;
        if(v.matches("\\d{7}")){idx=1;}
        else if(v.matches("\\d{7}N")){idx=1;semi=true;empty=true;}
        else if(v.matches("\\d{4}(LB|BN|LBB|MR|BNB|BNE|LBE|BNF|AH|AGI|AGJ|AGF|AHE|AGH|AGG|MRD|AGD|MRF|MRE|LBD|AG|AHF|AHA|DZ|AGB|AGE|DZE)")||v.matches("\\dH\\d{5}")){idx=2;}
        else if(v.matches("\\d{4}(TMR|TLB|TR|TAG|TAH)")){idx=2;semi=true;empty=true;}
        else if(v.matches("\\d{3}[ABCDEFHJKLMOPQRSTUWXYZ]{2}\\d{2}")||v.matches("\\d{4}[ABCDEFHJKLMOPQRSTUWXYZ]{2}\\d{2}")&&!v.matches("\\d{4}(AA|BA)[1-9]0")){idx=3;}
        else if(v.matches("0[1-9]KG.*")||v.matches("[A-Z]\\d{4}[A-Z]{1,2}")){idx=4;}
        else if(v.matches("01M0.*")||v.matches("\\d{5}[A-Z]{3}")||v.matches("\\d{2}[A-Z]\\d{3}[A-Z]{2}")){idx=5;}
        else if(v.matches("\\d{4}(AA|BA)[1-9]0")){idx=5;semi=true;empty=true;}
        else if(v.matches("\\d{2}[A-Z]\\d{4}")||v.matches("\\d{2}[A-Z]{3}\\d{2,3}")||v.matches("\\d{2}[A-Z]{2}\\d{3,4}")){idx=6;}
        else if(v.matches("\\d{3}[A-Z]{3}\\d{2}")){idx=7;}
        country.setSelection(idx);
        if(semi){vehicle.setSelection(2); load.setSelection(1);} else if(idx==6){vehicle.setSelection(0);load.setSelection(0);}
    }

    void startVoice(){
        if(listening){ stopVoice(); return; }
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},100); status.setText("لطفاً اجازه میکروفون را بدهید و دوباره بزنید"); return; }
        if(!SpeechRecognizer.isRecognitionAvailable(this)){status.setText("سرویس تشخیص گفتار روی این گوشی در دسترس نیست");return;}
        if(recognizer!=null) recognizer.destroy(); recognizer=SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle p){status.setText("🎙️ در حال شنیدن...");}
            public void onBeginningOfSpeech(){status.setText("🎙️ صحبت کنید...");}
            public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){}
            public void onEndOfSpeech(){status.setText("در حال پردازش...");}
            public void onError(int e){listening=false; voice.setText("🎙️ ثبت با صدا"); status.setText(errorText(e));}
            public void onResults(Bundle b){listening=false; voice.setText("🎙️ ثبت با صدا"); ArrayList<String> x=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(x!=null&&!x.isEmpty()) parseVoice(x.get(0)); else status.setText("صدایی تشخیص داده نشد");}
            public void onPartialResults(Bundle b){} public void onEvent(int a,Bundle b){}
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"fa-IR"); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"fa-IR"); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true); i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,5);
        listening=true; voice.setText("⏹ توقف شنیدن"); recognizer.startListening(i);
    }
    void stopVoice(){ if(recognizer!=null) recognizer.stopListening(); listening=false; voice.setText("🎙️ ثبت با صدا"); status.setText("آماده ثبت"); }
    String errorText(int e){ switch(e){case SpeechRecognizer.ERROR_AUDIO:return "خطا در دریافت صدای میکروفون";case SpeechRecognizer.ERROR_CLIENT:return "خطای داخلی تشخیص صدا";case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:return "اجازه میکروفون داده نشده است";case SpeechRecognizer.ERROR_NETWORK:return "خطای شبکه در تشخیص صدا";case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:return "مهلت ارتباط با سرویس صدا تمام شد";case SpeechRecognizer.ERROR_NO_MATCH:return "صدای قابل تشخیصی پیدا نشد؛ دوباره تلاش کنید";case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:return "سرویس تشخیص صدا مشغول است؛ دوباره تلاش کنید";case SpeechRecognizer.ERROR_SERVER:return "خطای سرویس تشخیص صدا";case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:return "صدایی دریافت نشد؛ دوباره صحبت کنید";default:return "خطای تشخیص صدا: "+e;} }

    void parseVoice(String raw){
        heard.setText("شنیده شد: "+raw); String s=normalize(raw);
        String p=findPlate(s); if(!p.isEmpty()){plate.setText(p); detectCountry(p);}
        if(s.contains("کامیون")){vehicle.setSelection(0);} else if(s.contains("کشنده")){vehicle.setSelection(1);} else if(s.contains("نیمهیدک")||s.contains("نیمه یدک")){vehicle.setSelection(2);}
        if(s.contains("خالی")){load.setSelection(1);} else if(s.contains("پر")){load.setSelection(0);}
        int n=s.indexOf("بار"); if(n>=0 && n+3<s.length()) note.setText(raw.substring(Math.min(raw.length(),Math.max(0,n+3))).trim().replaceFirst("^[،,: ]+",""));
        status.setText("اطلاعات تشخیص داده شد؛ قبل از ثبت بررسی کنید");
    }
    String findPlate(String s){
        String compact=s.replace("پلاک","").replace("شماره"," ").replaceAll("[،,:؛]"," ").trim();
        String[] words=compact.split("\\s+"); StringBuilder b=new StringBuilder();
        for(String w:words){ if(w.matches("[0-9۰-۹]{1,7}")||w.matches("[A-Za-zآ-ی]{1,3}")||w.matches("[0-9۰-۹]+[A-Za-zآ-ی]+[0-9۰-۹]+")){ b.append(w); if(b.length()>3) {String z=normalize(b.toString()); if(z.matches("[0-9A-Z]{5,11}")) return z;} } }
        for(String w:words){String z=normalize(w); if(z.matches("[0-9A-Z]{5,11}")&&z.matches(".*[0-9].*")) return z;}
        return "";
    }

    String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    void loadToday(){try{String q=getPreferences(0).getString(PREF+today(),"[]");JSONArray a=new JSONArray(q); for(int i=0;i<a.length();i++)rows.add(a.getJSONObject(i));}catch(Exception ignored){}}
    boolean duplicate(String p){for(JSONObject o:rows)if(o.optString("plate").equalsIgnoreCase(p))return true;return false;}
    void saveRow(){String p=normalize(plate.getText().toString()); if(p.isEmpty()){status.setText("پلاک را وارد کنید");return;} if(duplicate(p)){status.setText("این پلاک امروز قبلاً ثبت شده است");return;} try{JSONObject o=new JSONObject();o.put("plate",p);o.put("country",country.getSelectedItem().toString());o.put("vehicle",vehicle.getSelectedItem().toString());o.put("load",load.getSelectedItem().toString());o.put("note",note.getText().toString());o.put("time",new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date()));rows.add(o);saveToday();status.setText("ثبت شد ✓");plate.setText("");note.setText("");country.setSelection(0);vehicle.setSelection(0);load.setSelection(0);}catch(Exception e){status.setText("خطا در ذخیره اطلاعات");}}
    void saveToday(){JSONArray a=new JSONArray();for(JSONObject o:rows)a.put(o);getPreferences(0).edit().putString(PREF+today(),a.toString()).apply();}
    @Override protected void onDestroy(){if(recognizer!=null){recognizer.destroy();recognizer=null;}super.onDestroy();}
}
